import React from "react";

const Admin = ()=>{
    return(
        <>
        <h1>testing----</h1>
        </>
    )
}

export default Admin